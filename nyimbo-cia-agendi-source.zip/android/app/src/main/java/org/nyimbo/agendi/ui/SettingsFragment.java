package org.nyimbo.agendi.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import org.nyimbo.agendi.R;
import org.nyimbo.agendi.sync.EventReminderScheduler;

public class SettingsFragment extends Fragment {
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle saved) {
        View root = inflater.inflate(R.layout.fragment_settings, container, false);
        var preferences = requireContext().getSharedPreferences("preferences", 0);
        MaterialButtonToggleGroup appearance = root.findViewById(R.id.appearance_toggle);
        appearance.check(preferences.getBoolean("dark", false) ? R.id.theme_dark : R.id.theme_light);
        appearance.addOnButtonCheckedListener((group, checkedId, checked) -> {
            if (!checked) return;
            boolean dark = checkedId == R.id.theme_dark;
            preferences.edit().putBoolean("dark", dark).apply();
            AppCompatDelegate.setDefaultNightMode(dark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        });
        MaterialSwitch notifications = root.findViewById(R.id.notifications);
        boolean granted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        notifications.setChecked(preferences.getBoolean("eventNotifications", false) && granted);
        notifications.setOnCheckedChangeListener((button, checked) -> {
            if (checked && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifications.setChecked(false); requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 108); return;
            }
            preferences.edit().putBoolean("eventNotifications", checked).apply();
            if (checked) EventReminderScheduler.scheduleBookmarked(requireContext());
            updatePushSubscription(checked);
        });
        return root;
    }
    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 108 && getContext() != null) {
            boolean allowed = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            requireContext().getSharedPreferences("preferences", 0).edit().putBoolean("eventNotifications", allowed).apply();
            if (allowed) { MaterialSwitch toggle = getView() == null ? null : getView().findViewById(R.id.notifications); if (toggle != null) toggle.setChecked(true); EventReminderScheduler.scheduleBookmarked(requireContext()); }
            Toast.makeText(requireContext(), allowed ? "Event reminders are on." : "Notifications remain off.", Toast.LENGTH_SHORT).show();
        }
    }
    private void updatePushSubscription(boolean enabled) {
        if (FirebaseApp.getApps(requireContext()).isEmpty()) {
            if (enabled) Toast.makeText(requireContext(), "On-device reminders are enabled. Remote updates need Firebase setup.", Toast.LENGTH_LONG).show();
            return;
        }
        if (enabled) FirebaseMessaging.getInstance().subscribeToTopic("church_updates");
        else FirebaseMessaging.getInstance().unsubscribeFromTopic("church_updates");
    }
}
