package org.nyimbo.agendi.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.SparseArray;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.appbar.MaterialToolbar;
import org.nyimbo.agendi.R;
import org.nyimbo.agendi.sync.SyncWorker;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private final SparseArray<Fragment> fragments = new SparseArray<>();
    private int activeId = 0;
    @Override protected void onCreate(Bundle saved) {
        SplashScreen.installSplashScreen(this);
        if (getSharedPreferences("preferences", MODE_PRIVATE).getBoolean("dark", false)) AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        else AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(saved); setContentView(R.layout.activity_main);
        int[] navIds = {R.id.nav_home, R.id.nav_events, R.id.nav_favorites, R.id.nav_settings};
        for (int navId : navIds) { Fragment restored = getSupportFragmentManager().findFragmentByTag("nav-" + navId); if (restored != null) fragments.put(navId, restored); }
        if (saved != null) activeId = saved.getInt("active", R.id.nav_home);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setLogoDescription(getString(R.string.app_logo_description));
        setSupportActionBar(toolbar);
        BottomNavigationView navigation = findViewById(R.id.bottom_navigation);
        navigation.setOnItemSelectedListener(item -> { show(item.getItemId()); return true; });
        int first = saved == null ? R.id.nav_home : saved.getInt("active", R.id.nav_home);
        navigation.setSelectedItemId(first);
        if (fragments.get(first) == null) show(first);
        scheduleSync();
    }
    private Fragment fragmentFor(int id) {
        Fragment existing = fragments.get(id); if (existing != null) return existing;
        Fragment next;
        if (id == R.id.nav_events) next = new EventsFragment();
        else if (id == R.id.nav_favorites) next = HymnsFragment.newInstance(true);
        else if (id == R.id.nav_settings) next = new SettingsFragment();
        else next = HymnsFragment.newInstance(false);
        fragments.put(id, next); return next;
    }
    private void show(int id) {
        FragmentManager fm = getSupportFragmentManager(); FragmentTransaction tx = fm.beginTransaction();
        Fragment current = fragments.get(activeId); if (current != null) tx.hide(current);
        Fragment target = fragmentFor(id);
        if (target.isAdded()) tx.show(target); else tx.add(R.id.content_container, target, "nav-" + id);
        tx.commit(); activeId = id;
    }
    private void scheduleSync() {
        Constraints network = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(SyncWorker.class, 6, TimeUnit.HOURS).setConstraints(network).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("nyimbo-periodic-sync", ExistingPeriodicWorkPolicy.KEEP, periodic);
        OneTimeWorkRequest initial = new OneTimeWorkRequest.Builder(SyncWorker.class).setConstraints(network).build();
        WorkManager.getInstance(this).enqueueUniqueWork("nyimbo-initial-sync", ExistingWorkPolicy.KEEP, initial);
    }
    public void openReader(long id) { startActivity(new Intent(this, ReaderActivity.class).putExtra(ReaderActivity.EXTRA_HYMN_ID, id)); }
    public void openHymns() { ((BottomNavigationView)findViewById(R.id.bottom_navigation)).setSelectedItemId(R.id.nav_home); }
    @Override protected void onSaveInstanceState(Bundle out) { out.putInt("active", activeId); super.onSaveInstanceState(out); }
}
