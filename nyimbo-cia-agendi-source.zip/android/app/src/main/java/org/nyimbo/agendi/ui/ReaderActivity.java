package org.nyimbo.agendi.ui;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import org.nyimbo.agendi.R;
import org.nyimbo.agendi.data.NyimboDatabase;
import org.nyimbo.agendi.model.HymnEntity;
import org.nyimbo.agendi.repository.HymnRepository;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReaderActivity extends AppCompatActivity {
    public static final String EXTRA_HYMN_ID = "hymn_id";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private HymnEntity hymn;
    private TextView number, title, lyrics;
    private MenuItem favoriteAction;

    @Override protected void onCreate(@Nullable Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_reader);
        MaterialToolbar toolbar = findViewById(R.id.reader_toolbar);
        toolbar.setLogoDescription(getString(R.string.app_logo_description));
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.inflateMenu(R.menu.reader_actions);
        favoriteAction = toolbar.getMenu().findItem(R.id.reader_favorite_action);
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.reader_favorite_action) {
                toggleFavorite();
                return true;
            }
            return false;
        });
        number = findViewById(R.id.reader_number);
        title = findViewById(R.id.reader_title);
        lyrics = findViewById(R.id.reader_lyrics);
        load(getIntent().getLongExtra(EXTRA_HYMN_ID, -1));
    }

    private void load(long id) {
        io.execute(() -> {
            HymnEntity loaded = NyimboDatabase.get(this).hymns().get(id);
            if (loaded == null) {
                runOnUiThread(this::finish);
                return;
            }
            NyimboDatabase.get(this).hymns().markViewed(id, System.currentTimeMillis());
            runOnUiThread(() -> render(loaded));
        });
    }

    private void render(HymnEntity hymn) {
        this.hymn = hymn;
        number.setText(String.format(Locale.getDefault(), "%d.", hymn.displayNumber()));
        title.setText(hymn.title);
        lyrics.setText(hymn.lyrics == null || hymn.lyrics.trim().isEmpty()
            ? getString(R.string.lyrics_unavailable)
            : hymn.lyrics);
        updateFavoriteAction();
    }

    private void toggleFavorite() {
        if (hymn == null) return;
        hymn.favorite = !hymn.favorite;
        updateFavoriteAction();
        HymnRepository.get(this).favorite(hymn.id, hymn.favorite);
    }

    private void updateFavoriteAction() {
        if (favoriteAction == null || hymn == null) return;
        favoriteAction.setIcon(hymn.favorite
            ? android.R.drawable.btn_star_big_on
            : android.R.drawable.btn_star_big_off);
        favoriteAction.setTitle(hymn.favorite ? "Remove saved hymn" : "Save hymn");
    }

    @Override protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }
}
